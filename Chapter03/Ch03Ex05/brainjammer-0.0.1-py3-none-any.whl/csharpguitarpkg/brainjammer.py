def brainjammer():
    print("Gaining knowledge for earning DP-203 with csharpguitar and brainjammer")